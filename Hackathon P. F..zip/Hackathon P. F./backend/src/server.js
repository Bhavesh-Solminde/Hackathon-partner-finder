import ENV from './ENV.js'
import app from './app.js'
import { connectDB } from './lib/db.js'



app.listen(ENV.PORT, () => {
    console.log(`Server is running on port ${ENV.PORT}`)
})

connectDB()
  .then(() => {
    console.log("MongoDB connected successfully");
  })
  .catch((err) => {
    console.error("MongoDB connection failed:", err);
    process.exit(1);
  });